Atomic Script - complete project source

This archive contains the complete React + Vite + TanStack Start project source,
plus the standalone PHP page under public/atomic-php-source/.

Run the frontend:
  bun install
  bun run dev

The following are intentionally excluded:
  .env.local  (private project configuration)
  node_modules/ (reinstall with bun install)
  .git/ (version-control metadata)
